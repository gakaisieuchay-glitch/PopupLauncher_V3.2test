package com.example.popuplauncher.cache

import android.app.ActivityManager
import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.Drawable
import android.util.LruCache
import com.example.popuplauncher.AppEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * In-memory app-icon cache so the RecyclerView never re-resolves (and the
 * PackageManager never re-decodes) a Drawable it already loaded once while
 * scrolling. Item 1 of the V3 spec ("stop fetching raw icons synchronously
 * during UI rendering") — this is the highest-value piece of it for a device
 * like the Samsung A12: `PackageManager.getActivityIcon()` was previously
 * called on the Service's main thread inside `onBindViewHolder`.
 *
 * Deliberately count-based (not byte-size-aware) for now: a byte-accurate
 * LruCache needs `sizeOf()` overridden per-Bitmap, which is a reasonable next
 * step but adds a mocking surface this phase doesn't need yet.
 */
object IconCache {

    private var cache: LruCache<String, Drawable>? = null

    private fun cacheFor(context: Context): LruCache<String, Drawable> {
        cache?.let { return it }
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memoryClassMb = activityManager?.memoryClass ?: 32
        // ~1/16th of the app's memory class, in "one entry per ~1KB" terms, clamped
        // to a sane range so a very low or very high memoryClass doesn't misbehave.
        val maxEntries = (memoryClassMb * 1024 / 16).coerceIn(64, 512)
        return LruCache<String, Drawable>(maxEntries).also { cache = it }
    }

    private fun keyFor(entry: AppEntry): String = "${entry.packageName}/${entry.activityName}"

    /** Synchronous, non-blocking cache read for the icon's fast path (no coroutine needed). */
    fun getCached(entry: AppEntry): Drawable? = cache?.get(keyFor(entry))

    /**
     * Resolves the icon off the main thread and caches the result.
     * Safe to call repeatedly for the same entry — subsequent calls hit the cache.
     */
    suspend fun load(context: Context, entry: AppEntry): Drawable? {
        val appContext = context.applicationContext
        val memCache = cacheFor(appContext)
        memCache.get(keyFor(entry))?.let { return it }

        return withContext(Dispatchers.IO) {
            val packageManager = appContext.packageManager
            val drawable = runCatching {
                packageManager.getActivityIcon(
                    ComponentName(entry.packageName, entry.activityName)
                )
            }.getOrElse {
                runCatching { packageManager.getApplicationIcon(entry.packageName) }.getOrNull()
            }
            drawable?.also { memCache.put(keyFor(entry), it) }
        }
    }

    /** Call from onTrimMemory or a package-changed broadcast in a later phase. */
    fun clear() {
        cache?.evictAll()
    }
}
