package com.example.popuplauncher

import android.graphics.Rect
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Root/SU detector and command runner. Priority #1 in the launch engine.
 *
 * All privileged process work is suspendable and runs on Dispatchers.IO.
 * No blocking sleep is performed on the caller thread.
 */
object RootManager {

    private const val TAG = "RootManager"
    private const val CHECK_TIMEOUT_MS = 1_200L
    private const val EXEC_TIMEOUT_MS = 4_000L
    private const val WINDOWING_MODE_FREEFORM = 5

    private const val TASK_LOOKUP_ATTEMPTS = 4
    private const val TASK_LOOKUP_RETRY_DELAY_MS = 150L

    /** True when a functional su binary can execute `id` as uid 0. */
    suspend fun hasRootAccess(): Boolean = withContext(Dispatchers.IO) {
        runSuCommand("id", CHECK_TIMEOUT_MS)?.let { result ->
            result.exitCode == 0 && result.output.contains("uid=0")
        } == true
    }

    /**
     * Starts the target activity in Freeform mode and best-effort resizes its task.
     * The complete operation is suspendable and performs all process I/O on IO.
     */
    suspend fun launchFreeform(
        targetPackage: String,
        targetActivity: String,
        bounds: Rect? = null
    ): Boolean = withContext(Dispatchers.IO) {
        val component = "$targetPackage/$targetActivity"
        if (!COMPONENT_REGEX.matches(component)) {
            Log.w(TAG, "Component không hợp lệ: $component")
            return@withContext false
        }

        val command = "am start -n ${shellQuote(component)} --windowingMode $WINDOWING_MODE_FREEFORM"
        val result = runSuCommand(command, EXEC_TIMEOUT_MS)
        if (result == null) {
            Log.w(TAG, "Không thể thực thi su")
            return@withContext false
        }

        Log.d(TAG, "su -c exitCode=${result.exitCode}: ${result.output.take(500)}")
        if (result.exitCode != 0) return@withContext false

        if (bounds != null && bounds.width() > 0 && bounds.height() > 0) {
            applyBoundsBestEffort(targetPackage, bounds)
        }

        true
    }

    /** Best-effort only: failure here must never invalidate a successful launch. */
    private suspend fun applyBoundsBestEffort(targetPackage: String, bounds: Rect) {
        repeat(TASK_LOOKUP_ATTEMPTS) { index ->
            val attempt = index + 1
            val dump = runSuCommand("dumpsys activity activities", CHECK_TIMEOUT_MS)
            val taskId = dump?.output?.let { findTaskId(it, targetPackage) }

            if (taskId != null) {
                val boundsArg = "${bounds.left},${bounds.top},${bounds.right},${bounds.bottom}"
                val resizeResult = runSuCommand(
                    "am task resize $taskId $boundsArg",
                    EXEC_TIMEOUT_MS
                )
                Log.d(
                    TAG,
                    "am task resize taskId=$taskId bounds=$boundsArg " +
                        "exitCode=${resizeResult?.exitCode}"
                )
                return
            }

            if (attempt < TASK_LOOKUP_ATTEMPTS) {
                delay(TASK_LOOKUP_RETRY_DELAY_MS)
            }
        }

        Log.w(
            TAG,
            "Không tìm thấy TaskRecord của $targetPackage để resize " +
                "(best-effort, ROM có thể không hỗ trợ)."
        )
    }

    private fun findTaskId(dumpsysOutput: String, packageName: String): Int? {
        val regex = Regex("""#(\\d+)\\s+A=${Regex.escape(packageName)}\\b""")
        return regex.findAll(dumpsysOutput)
            .lastOrNull()
            ?.groupValues
            ?.getOrNull(1)
            ?.toIntOrNull()
    }

    private fun shellQuote(value: String): String =
        "'" + value.replace("'", "'\\''") + "'"

    /**
     * Execute one `su -c` command without starving the process pipe.
     * stdout/stderr are drained concurrently while the timeout is measured.
     */
    private suspend fun runSuCommand(
        command: String,
        timeoutMs: Long
    ): CommandResult? = withContext(Dispatchers.IO) {
        try {
            coroutineScope {
                val process = ProcessBuilder("su", "-c", command)
                    .redirectErrorStream(true)
                    .start()

                val outputJob = async(Dispatchers.IO) {
                    process.inputStream.bufferedReader().use { it.readText() }
                }

                try {
                    if (!process.waitFor(timeoutMs, TimeUnit.MILLISECONDS)) {
                        process.destroy()
                        if (process.isAlive) process.destroyForcibly()
                        outputJob.cancel()
                        return@coroutineScope null
                    }

                    CommandResult(
                        exitCode = process.exitValue(),
                        output = outputJob.await()
                    )
                } catch (t: Throwable) {
                    process.destroy()
                    if (process.isAlive) process.destroyForcibly()
                    outputJob.cancel()
                    throw t
                }
            }
        } catch (t: Throwable) {
            Log.d(TAG, "SU không khả dụng: ${t.message}")
            null
        }
    }

    private data class CommandResult(
        val exitCode: Int,
        val output: String
    )

    private val COMPONENT_REGEX =
        Regex("""^[A-Za-z0-9_.$]+/[A-Za-z0-9_.$]+$""")
}
