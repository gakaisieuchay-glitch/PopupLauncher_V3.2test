package com.example.popuplauncher.search

import java.text.Normalizer
import java.util.Locale

/**
 * Accent-insensitive, initials-aware fuzzy matching for the app search box
 * (item spec: "bo dấu Tiếng Việt" + search by full name / initials / package name).
 *
 * Pure/stateless on purpose: no Context dependency, trivially unit-testable,
 * cheap enough to run on every keystroke without its own dispatcher.
 */
object VietnameseSearch {

    /**
     * Lowercases, strips Vietnamese diacritics (including "đ", which does NOT
     * decompose under NFD like the other accented letters do) and combining marks.
     */
    fun normalize(input: String): String {
        val lower = input
            .lowercase(Locale.US)
            .replace('đ', 'd')
        val decomposed = Normalizer.normalize(lower, Normalizer.Form.NFD)
        return COMBINING_MARKS.replace(decomposed, "")
    }

    /** "Nhắn Tin" -> "nt", so a query like "nt" or "zl" matches by initials. */
    private fun initialsOf(label: String): String =
        label
            .trim()
            .split(WHITESPACE)
            .mapNotNull { it.firstOrNull() }
            .joinToString(separator = "")
            .let(::normalize)

    /**
     * True if [query] plausibly refers to an app named [label] with package
     * [packageName]. Checked in order: normalized substring of the label,
     * an initials match, then a substring of the package name.
     */
    fun matches(query: String, label: String, packageName: String): Boolean {
        val trimmedQuery = query.trim()
        if (trimmedQuery.isEmpty()) return true

        val normalizedQuery = normalize(trimmedQuery)
        val normalizedLabel = normalize(label)

        return normalizedLabel.contains(normalizedQuery) ||
            initialsOf(label).contains(normalizedQuery) ||
            packageName.lowercase(Locale.US).contains(normalizedQuery)
    }

    private val COMBINING_MARKS = Regex("\\p{Mn}+")
    private val WHITESPACE = Regex("\\s+")
}
