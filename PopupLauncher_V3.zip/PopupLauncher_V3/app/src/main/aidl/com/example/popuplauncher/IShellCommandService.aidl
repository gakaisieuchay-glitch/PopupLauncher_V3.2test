// IShellCommandService.aidl
package com.example.popuplauncher;

/**
 * Interface AIDL cho UserService chạy dưới quyền Shizuku (shell UID).
 * Dùng để thực thi lệnh "am start ... --windowingMode 5" mà không cần Root.
 */
interface IShellCommandService {

    /**
     * Thực thi 1 lệnh shell và trả về exit code.
     * command: mảng các tham số lệnh, ví dụ: ["am", "start", "-n", "pkg/act", "--windowingMode", "5"]
     */
    int execCommand(in String[] command);

    /**
     * Mở app dưới dạng cửa sổ Pop-up (Freeform) VÀ áp dụng kích thước mong muốn
     * (best-effort) trong CÙNG 1 lượt gọi Binder, để tránh phải round-trip IPC
     * nhiều lần từ tiến trình chính của app sang tiến trình shell của Shizuku.
     *
     * Nếu (right - left) <= 0 hoặc (bottom - top) <= 0, bước resize sẽ được bỏ qua
     * và app chỉ mở ở kích thước Freeform mặc định của hệ thống.
     *
     * Trả về exit code của lệnh "am start" (0 = thành công mở Pop-up).
     */
    int launchFreeformPopup(
        in String targetPackage,
        in String targetActivity,
        in int left,
        in int top,
        in int right,
        in int bottom
    );

    /**
     * Hủy tiến trình UserService khi không cần dùng nữa để giải phóng tài nguyên (Memory Saver).
     */
    void destroy() = 16777114; // mã code đặc biệt Shizuku dùng để tắt UserService an toàn
}
