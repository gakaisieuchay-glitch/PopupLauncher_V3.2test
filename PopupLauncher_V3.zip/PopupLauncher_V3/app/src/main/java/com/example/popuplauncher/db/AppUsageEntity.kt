package com.example.popuplauncher.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room-backed replacement for the old per-package SharedPreferences int counter
 * (`usage_count_<package>`). One row per package the user has ever launched as
 * a Pop-up. `lastOpenedAt` is stored now (not previously tracked) so future
 * phases can add a "Recents" tab without another schema change.
 */
@Entity(tableName = "app_usage")
data class AppUsageEntity(
    @PrimaryKey val packageName: String,
    val launchCount: Int = 0,
    val lastOpenedAt: Long = 0L
)
