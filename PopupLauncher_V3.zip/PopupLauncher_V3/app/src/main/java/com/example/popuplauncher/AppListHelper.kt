package com.example.popuplauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import com.example.popuplauncher.db.AppUsageDatabase
import com.example.popuplauncher.db.AppUsageEntity
import com.example.popuplauncher.search.VietnameseSearch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Lightweight app model.
 *
 * Icons are intentionally NOT stored here. Drawable/Bitmap instances can be
 * relatively large and are now resolved (and cached) by [com.example.popuplauncher.cache.IconCache]
 * only while a RecyclerView row is bound.
 */
data class AppEntry(
    val packageName: String,
    val activityName: String,
    val label: String,
    var isFavorite: Boolean = false
)

class AppListHelper(context: Context) {

    private val appContext = context.applicationContext
    private val packageManager: PackageManager = appContext.packageManager
    private val prefs: SharedPreferences =
        appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val usageDao by lazy { AppUsageDatabase.getInstance(appContext).appUsageDao() }

    companion object {
        private const val PREFS_NAME = "popup_launcher_prefs"
        private const val KEY_FAVORITES = "favorite_packages"
        private const val KEY_USAGE_COUNT_PREFIX = "usage_count_"
        private const val KEY_APP_PRESET_PREFIX = "app_preset_"
        private const val KEY_USAGE_MIGRATED_TO_ROOM = "usage_migrated_to_room_v1"
        private const val SEPARATOR = "||"

        /** Quick Pinned Bar: tối đa 4 app được ghim, đúng theo yêu cầu gốc. */
        const val MAX_FAVORITES = 4
    }

    /**
     * Danh sách app có thể khởi chạy, đã sắp xếp theo:
     *  1) App đã Ghim (Quick Pinned Bar) lên đầu.
     *  2) Trong số app còn lại, app dùng NHIỀU LẦN NHẤT (usage count, từ Room) lên trước.
     *  3) Cuối cùng mới theo alphabet, để danh sách luôn ổn định/dễ tìm.
     *
     * `suspend` + tự `withContext(Dispatchers.IO)`: enumerate + loadLabel() cho toàn bộ
     * app cài trên máy là việc tốn thời gian (PackageManager, không có cache), nên hàm
     * này an toàn để gọi từ bất kỳ coroutine nào mà không làm treo UI thread của Service.
     */
    suspend fun getLaunchableApps(): List<AppEntry> = withContext(Dispatchers.IO) {
        migrateLegacyUsageIfNeeded()

        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        // Một lượt đọc Room duy nhất cho toàn bộ danh sách, thay vì 1 lượt đọc
        // SharedPreferences cho MỖI app (như cách làm cũ) khi sắp xếp bên dưới.
        val usageByPackage = usageDao.getAll().associateBy({ it.packageName }, { it.launchCount })

        packageManager.queryIntentActivities(mainIntent, 0)
            .asSequence()
            .filter { it.activityInfo.packageName != appContext.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { resolveInfo ->
                val activityInfo = resolveInfo.activityInfo
                AppEntry(
                    packageName = activityInfo.packageName,
                    activityName = activityInfo.name,
                    label = resolveInfo.loadLabel(packageManager).toString(),
                    isFavorite = isFavorite(activityInfo.packageName)
                )
            }
            .sortedWith(
                compareByDescending<AppEntry> { it.isFavorite }
                    .thenByDescending { usageByPackage[it.packageName] ?: 0 }
                    .thenBy { it.label.lowercase() }
            )
            .toList()
    }

    /**
     * Advanced Search Engine (accent-insensitive + initials + package name).
     * Thao tác lọc trong bộ nhớ, không chạm PackageManager, nên vẫn nhanh dù gọi
     * trên bất kỳ luồng nào — luồng debounce 250ms nằm ở phía gọi (FloatingService).
     */
    fun filterApps(apps: List<AppEntry>, query: String): List<AppEntry> {
        if (query.isBlank()) return apps
        return apps.filter { VietnameseSearch.matches(query, it.label, it.packageName) }
    }

    fun getFavoriteApps(allApps: List<AppEntry>): List<AppEntry> {
        val favoritePackages = getFavoritePackages()
        val appsByPackage = allApps.associateBy { it.packageName }
        return favoritePackages.mapNotNull { appsByPackage[it] }
    }

    /**
     * Legacy synchronous icon loader. Superseded by
     * [com.example.popuplauncher.cache.IconCache], which caches the result and does the
     * PackageManager call off the main thread. Kept here only so nothing else that may
     * still reference it breaks.
     */
    fun loadIcon(entry: AppEntry) = runCatching {
        packageManager.getActivityIcon(
            ComponentName(entry.packageName, entry.activityName)
        )
    }.getOrElse {
        runCatching { packageManager.getApplicationIcon(entry.packageName) }.getOrNull()
    }

    private fun getFavoritePackages(): List<String> {
        val raw = prefs.getString(KEY_FAVORITES, null) ?: return emptyList()
        return raw.split(SEPARATOR).filter { it.isNotBlank() }
    }

    /**
     * Ghim/bỏ ghim 1 app vào Quick Pinned Bar (tối đa [MAX_FAVORITES] app).
     * Khi đã đầy, app được ghim SỚM NHẤT sẽ tự động bị đẩy ra để nhường chỗ.
     */
    fun toggleFavorite(packageName: String): List<String> {
        val current = getFavoritePackages().toMutableList()
        if (current.contains(packageName)) {
            current.remove(packageName)
        } else {
            if (current.size >= MAX_FAVORITES) current.removeAt(0)
            current.add(packageName)
        }
        prefs.edit().putString(KEY_FAVORITES, current.joinToString(SEPARATOR)).apply()
        return current
    }

    fun isFavorite(packageName: String): Boolean = getFavoritePackages().contains(packageName)

    // ---------------------------------------------------------------------
    // Usage tracking (Room): phục vụ việc tự động đẩy "app dùng nhiều nhất" lên đầu
    // danh sách trong getLaunchableApps(), bổ trợ cho Quick Pinned Bar thủ công.
    // ---------------------------------------------------------------------

    /** Gọi mỗi khi 1 app được mở dưới dạng Pop-up, để tăng bộ đếm sử dụng của app đó. */
    suspend fun recordAppLaunched(packageName: String) = withContext(Dispatchers.IO) {
        val current = usageDao.getByPackage(packageName)
        val updated = (current ?: AppUsageEntity(packageName = packageName)).copy(
            launchCount = (current?.launchCount ?: 0) + 1,
            lastOpenedAt = System.currentTimeMillis()
        )
        usageDao.upsert(updated)
    }

    /**
     * Chạy đúng 1 lần: chuyển toàn bộ bộ đếm cũ (SharedPreferences, từ trước khi có Room)
     * sang bảng `app_usage`, để người dùng nâng cấp lên V3 không bị mất lịch sử "app dùng
     * nhiều nhất". Sau khi chạy xong, đặt cờ để không bao giờ chạy lại.
     */
    private suspend fun migrateLegacyUsageIfNeeded() {
        if (prefs.getBoolean(KEY_USAGE_MIGRATED_TO_ROOM, false)) return

        prefs.all.keys
            .filter { it.startsWith(KEY_USAGE_COUNT_PREFIX) }
            .forEach { key ->
                val packageName = key.removePrefix(KEY_USAGE_COUNT_PREFIX)
                val count = prefs.getInt(key, 0)
                if (count > 0) {
                    usageDao.upsert(AppUsageEntity(packageName = packageName, launchCount = count))
                }
            }

        prefs.edit().putBoolean(KEY_USAGE_MIGRATED_TO_ROOM, true).apply()
    }

    // ---------------------------------------------------------------------
    // Per-App Layout Memory: tự động ghi nhớ tỷ lệ cửa sổ Pop-up mà người dùng
    // đã chọn RIÊNG cho từng app, để lần mở tiếp theo (kể cả mở 1 chạm từ
    // Quick Pinned Bar) tự áp dụng lại đúng kích thước đó mà không cần chọn lại.
    // ---------------------------------------------------------------------

    fun getPresetForApp(packageName: String): WindowSizePreset? {
        val savedName = prefs.getString(KEY_APP_PRESET_PREFIX + packageName, null)
        return WindowSizePreset.fromNameSafe(savedName)
    }

    fun savePresetForApp(packageName: String, preset: WindowSizePreset) {
        prefs.edit().putString(KEY_APP_PRESET_PREFIX + packageName, preset.name).apply()
    }
}
