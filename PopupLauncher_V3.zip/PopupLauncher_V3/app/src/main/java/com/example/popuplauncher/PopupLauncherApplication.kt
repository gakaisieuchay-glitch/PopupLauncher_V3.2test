package com.example.popuplauncher

import android.app.Application

class PopupLauncherApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        ShizukuManager.initialize(this)
    }
}
