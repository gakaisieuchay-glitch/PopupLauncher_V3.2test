package com.example.popuplauncher

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Rect
import android.os.Build
import android.os.IBinder
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import kotlin.coroutines.resume

/**
 * Priority Launch Engine:
 * 1) Root/SU
 * 2) Shizuku UserService (shell/root identity supplied by Shizuku)
 * 3) Native ActivityOptions fallback
 *
 * No ExecutorService is kept alive. Each launch is a coroutine Job owned by this manager's
 * application-scoped lifecycle and runs privileged/blocking work on Dispatchers.IO.
 */
object ShizukuManager {

    private const val TAG = "ShizukuManager"
    const val REQUEST_CODE_SHIZUKU_PERMISSION = 9001
    private const val WINDOWING_MODE_FREEFORM = 5
    private const val USER_SERVICE_TAG = "popup_launcher_shell_service"

    private val stateLock = Any()
    private val launchMutex = Mutex()

    @Volatile
    private var userServiceConnection: UserServiceConnectionImpl? = null

    @Volatile
    private var shellService: IShellCommandService? = null

    @Volatile
    private var isServiceBound = false

    private var applicationContext: Context? = null
    private var operationScope: CoroutineScope? = null

    interface PermissionResultListener {
        fun onPermissionResult(granted: Boolean)
    }

    @Volatile
    private var permissionResultListener: PermissionResultListener? = null

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.d(TAG, "Đã nhận Binder từ Shizuku.")
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        Log.w(TAG, "Binder Shizuku đã chết.")
        synchronized(stateLock) {
            shellService = null
            isServiceBound = false
            userServiceConnection = null
        }
    }

    private val requestPermissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == REQUEST_CODE_SHIZUKU_PERMISSION) {
                permissionResultListener?.onPermissionResult(
                    grantResult == PackageManager.PERMISSION_GRANTED
                )
            }
        }

    fun initialize(context: Context) {
        synchronized(stateLock) {
            if (applicationContext != null) return

            applicationContext = context.applicationContext
            operationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(requestPermissionResultListener)
        }
    }

    fun release() {
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(requestPermissionResultListener)
        permissionResultListener = null
        unbindUserService()

        synchronized(stateLock) {
            operationScope?.cancel()
            operationScope = null
            applicationContext = null
        }
    }

    fun setPermissionResultListener(listener: PermissionResultListener?) {
        permissionResultListener = listener
    }

    fun isShizukuAvailable(): Boolean = runCatching { Shizuku.pingBinder() }.getOrDefault(false)

    fun hasShizukuPermission(): Boolean {
        if (!isShizukuAvailable()) return false
        return runCatching {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
    }

    fun requestShizukuPermission() {
        if (!isShizukuAvailable()) return
        if (Shizuku.isPreV11()) return
        runCatching {
            Shizuku.requestPermission(REQUEST_CODE_SHIZUKU_PERMISSION)
        }.onFailure {
            Log.w(TAG, "Không thể yêu cầu quyền Shizuku: ${it.message}")
        }
    }

    private class UserServiceConnectionImpl(
        private val onReady: (IShellCommandService?) -> Unit
    ) : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val service = IShellCommandService.Stub.asInterface(binder)
            shellService = service
            isServiceBound = true
            onReady(service)
        }

        override fun onServiceDisconnected(name: ComponentName) {
            shellService = null
            isServiceBound = false
            onReady(null)
        }
    }

    private fun buildUserServiceArgs(context: Context): Shizuku.UserServiceArgs =
        Shizuku.UserServiceArgs(
            ComponentName(context.packageName, ShellCommandService::class.java.name)
        )
            .daemon(false)
            .tag(USER_SERVICE_TAG)
            .processNameSuffix("shell_service")
            .debuggable(false)
            .version(1)

    /**
     * Wait asynchronously for the UserService binder instead of nesting executor callbacks.
     * The current launch is serialized by [launchMutex], so only one bind/launch transaction
     * is active at a time.
     */
    private suspend fun bindUserServiceIfNeeded(context: Context): IShellCommandService? {
        val current = shellService
        if (isServiceBound && current != null) return current

        return suspendCancellableCoroutine { continuation ->
            val connection = UserServiceConnectionImpl { service ->
                if (!continuation.isActive) return@UserServiceConnectionImpl
                continuation.resume(service)
            }

            synchronized(stateLock) {
                userServiceConnection = connection
            }

            continuation.invokeOnCancellation {
                synchronized(stateLock) {
                    if (userServiceConnection === connection) {
                        userServiceConnection = null
                        shellService = null
                        isServiceBound = false
                    }
                }
                runCatching {
                    Shizuku.unbindUserService(
                        buildUserServiceArgs(context),
                        connection,
                        true
                    )
                }
            }

            runCatching {
                Shizuku.bindUserService(buildUserServiceArgs(context), connection)
            }.onFailure {
                Log.e(TAG, "bindUserService thất bại: ${it.message}", it)
                if (continuation.isActive) continuation.resume(null)
            }
        }
    }

    fun unbindUserService() {
        val context = applicationContext ?: return
        val connection = userServiceConnection

        if (connection == null) {
            shellService = null
            isServiceBound = false
            return
        }

        runCatching { shellService?.destroy() }
            .onFailure { Log.w(TAG, "destroy UserService thất bại: ${it.message}") }

        runCatching {
            Shizuku.unbindUserService(
                buildUserServiceArgs(context),
                connection,
                true
            )
        }.onFailure {
            Log.w(TAG, "unbindUserService thất bại: ${it.message}")
        }

        synchronized(stateLock) {
            if (userServiceConnection === connection) {
                userServiceConnection = null
            }
            shellService = null
            isServiceBound = false
        }
    }

    /**
     * Fire-and-forget launch entry point. The returned Job belongs to this manager's scope,
     * so cancellation is possible without leaking a thread or executor.
     */
    fun launchPopup(
        context: Context,
        targetPackage: String,
        targetActivity: String,
        bounds: Rect? = null
    ): Job? {
        val scope = synchronized(stateLock) {
            if (applicationContext == null) {
                applicationContext = context.applicationContext
            }
            operationScope ?: CoroutineScope(SupervisorJob() + Dispatchers.IO).also {
                operationScope = it
            }
        }

        val appContext = context.applicationContext
        return scope.launch {
            launchMutex.withLock {
                // Priority 1: Root
                if (RootManager.hasRootAccess()) {
                    if (RootManager.launchFreeform(targetPackage, targetActivity, bounds)) {
                        return@withLock
                    }
                    Log.w(TAG, "Root có sẵn nhưng launch thất bại, chuyển sang Shizuku/fallback.")
                }

                // Priority 2: Shizuku
                if (hasShizukuPermission()) {
                    val launchedViaShizuku = launchViaShizuku(
                        appContext,
                        targetPackage,
                        targetActivity,
                        bounds
                    )
                    if (launchedViaShizuku) return@withLock
                }

                // Priority 3: native ActivityOptions
                launchViaFallback(appContext, targetPackage, targetActivity, bounds)
            }
        }
    }

    private suspend fun launchViaShizuku(
        context: Context,
        targetPackage: String,
        targetActivity: String,
        bounds: Rect?
    ): Boolean {
        val service = bindUserServiceIfNeeded(context) ?: return false

        return try {
            val left = bounds?.left ?: 0
            val top = bounds?.top ?: 0
            val right = bounds?.right ?: 0
            val bottom = bounds?.bottom ?: 0

            val exitCode = withContext(Dispatchers.IO) {
                service.launchFreeformPopup(
                    targetPackage,
                    targetActivity,
                    left,
                    top,
                    right,
                    bottom
                )
            }

            Log.d(
                TAG,
                "Shizuku launchFreeformPopup exitCode=$exitCode " +
                    "component=$targetPackage/$targetActivity"
            )
            exitCode == 0
        } catch (t: Throwable) {
            Log.e(TAG, "Shizuku launch thất bại: ${t.message}", t)
            false
        } finally {
            // The service is intentionally short-lived: no shell-side process should remain
            // resident while the user is back in the game.
            unbindUserService()
        }
    }

    /**
     * Only the actual framework startActivity call hops to Main. No shell/dumpsys work does.
     */
    private suspend fun launchViaFallback(
        context: Context,
        targetPackage: String,
        targetActivity: String,
        bounds: Rect?
    ) {
        val intent = Intent().apply {
            component = ComponentName(targetPackage, targetActivity)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
        }

        val options = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            ActivityOptions.makeBasic().apply {
                launchWindowingMode = WINDOWING_MODE_FREEFORM
                if (bounds != null && bounds.width() > 0 && bounds.height() > 0) {
                    setLaunchBounds(bounds)
                }
            }
        } else {
            null
        }

        withContext(Dispatchers.Main.immediate) {
            try {
                if (options != null) {
                    context.startActivity(intent, options.toBundle())
                } else {
                    context.startActivity(intent)
                }
            } catch (t: Throwable) {
                Log.e(TAG, "Native freeform fallback thất bại: ${t.message}", t)
                runCatching {
                    context.startActivity(
                        Intent().apply {
                            component = ComponentName(targetPackage, targetActivity)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                    )
                }.onFailure {
                    Log.e(TAG, "Plain activity launch cũng thất bại: ${it.message}", it)
                }
            }
        }
    }
}
